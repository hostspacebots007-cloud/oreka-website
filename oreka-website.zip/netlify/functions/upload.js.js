import { getStore } from "@netlify/blobs";

export async function handler(event) {
  const formData = await event.request.formData();
  const fileUpload = formData.get("fileUpload");

  const store = getStore({ name: "UserUpload", consistency: "strong" });
  await store.set("unique-key", fileUpload);

  return {
    statusCode: 200,
    body: "Image uploaded successfully!",
  };
}